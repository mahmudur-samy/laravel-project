<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Wrestler;

class WrestlerControl extends Controller
{
public function index(){
	$wrestlers = Wrestler::latest()->paginate(50);
	return view('wrestlers.index', compact('wrestlers'));
}

    public function create(){
    	return view('wrestlers.create');
    }

    public function store(Request $request){
    	$request->validate([
    		'wrestler_id'=>'required',
    		'name'=> 'required',
    		'assigned_show'=>'required'
    	]);
    	Wrestler::create($request->all());

    	return redirect()->route('wrestlers.index')->with('success', 'Wrestler Info Added Successfully!');
    }
    public function edit(Wrestler $wrestler){
    	return view('wrestlers.edit', compact('wrestler'));
    }

    public function update(Request $request,Wrestler $wrestler){
    	$request->validate([
    		'wrestler_id'=>'required',
    		'name'=> 'required',
    		'assigned_show'=>'required'
    	]);

    	$wrestler->update($request->all());
    	return redirect()->route('wrestlers.index')->with('success', 'Updated Successfully!');
    }

    public function destroy(Wrestler $wrestler){
    	$wrestler->delete();
    	return redirect()->route('wrestlers.index')->with('success', 'Deleted Successfully!');

    }
}
