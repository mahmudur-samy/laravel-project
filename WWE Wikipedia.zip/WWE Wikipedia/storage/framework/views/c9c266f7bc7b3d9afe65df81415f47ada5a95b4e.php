<!DOCTYPE html>
<html>
<head>
	<title>Current Roster</title>
	<style type="text/css">
		a {
    text-decoration: none;
}
a:link, a:visited {
    color: blue;
}
a:hover {
    color: red;
}
	</style>
</head>
<body align="center" style="color: white; background-color: black;">
	<div class="container">
		<?php echo $__env->yieldContent('content'); ?>
	</div>
</body>
</html><?php /**PATH C:\xampp\htdocs\JoW\resources\views/wrestlers/layout.blade.php ENDPATH**/ ?>