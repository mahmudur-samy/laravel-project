<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Wrestler extends Model
{
    use HasFactory;

    protected $fillable = ['wrestler_id', 'name', 'assigned_show', 'wiki_link'];
}
