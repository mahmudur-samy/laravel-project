@extends('wrestlers.layout')

@section('content')
<div style="color: white;" align="center">

	<h1 style="font-family: Courier New">WIKIPEDIA  LINKS  OF  WWE  SUPERSTARS</h1>

	<button type="submit" style="background-color: brown;"><a href="{{route('wrestlers.create')}}" target="_blank" style="color: white; text-decoration: none;">Add New Wrestler</a></button><br>
	<h1>Current Roster</h1><br><br><br>

<div align="center" style="vertical-align: middle;">
	<table border="1" width="800" style="border: 3px double #CCCCCC;">
		<tr>
			<th>Wrestler ID</th>
			<th>Ring Name</th>
			<th>Assigned Show</th>
			<th>Action</th>
		</tr>
		@foreach ($wrestlers->sortBy('wrestler_id') as $wrestler)
		<tr>
			<td>{{$wrestler->wrestler_id}}</td>
			<td><a href="{{$wrestler->wiki_link}}" style="text-decoration: none;" target="_b">{{$wrestler->name}}</a></td>
			<td>{{$wrestler->assigned_show}}</td>
			<td align="center" style="vertical-align: middle;">
				<form action="{{route('wrestlers.destroy', $wrestler->id)}}" method="POST">
				<button type="submit" style="background-color: brown;"><a href="{{route('wrestlers.edit', $wrestler->id)}}" style="color: white; text-decoration: none;">Update</a></button>

				@csrf
				@method('DELETE')

				<button type="submit" style="color: white; background-color: brown;">Release</button>
			</form>
			</td>
		</tr>
		@endforeach
	</table>
</div>
</div>