@extends('wrestlers.layout')

@section('content')
<head>
	<title>Add New Wrestler's Info</title>
</head>

<h1>Add New Wrestler to the Roster</h1>

<div>
	 @if ($errors->any())
      <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
              <li>{{ $error }}</li>
            @endforeach
        </ul>
      </div><br />
    @endif
	<form action="{{route('wrestlers.store')}}" method="POST" target="_parent">
		@csrf
		Wrestler ID: <input type="text" name="wrestler_id" placeholder="Initials of the Name" style="border: 3px double #CCCCCC;"><br>
		Name: <input type="text" name="name" placeholder="Ring Name" style="border: 3px double #CCCCCC;"><br>
		Assigned Show: <input type="text" name="assigned_show" placeholder="Raw/Smackdown/NXT" style="border: 3px double #CCCCCC;"><br>
		Wikipedia Link: <input type="text" name="wiki_link" placeholder="htttp://wikipedia.org/XXXx" style="border: 3px double #CCCCCC;"><br>
		<br><br>
		<button type="submit" style="color: #FFFFFF; background-color: brown;">Add Wrestler</button>
	</form>
</div>