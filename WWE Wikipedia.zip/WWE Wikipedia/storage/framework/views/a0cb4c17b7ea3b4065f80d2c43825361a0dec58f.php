

<?php $__env->startSection('content'); ?>
<div style="color: white; background-color: black;" align="center">

<h1>Current Roster</h1>
<button type="submit" style="background-color: brown;"><a href="<?php echo e(route('wrestlers.create')); ?>" target="_blank" style="color: white; text-decoration: none;">Add New Wrestler</a></button><br><br><br>

<div align="center" style="vertical-align: middle;">
	<table border="1" width="800" style="border: 3px double #CCCCCC;">
		<tr>
			<th>Wrestler ID</th>
			<th>Ring Name</th>
			<th>Assigned Show</th>
			<th>Action</th>
		</tr>
		<?php $__currentLoopData = $wrestlers->sortBy('wrestler_id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wrestler): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><?php echo e($wrestler->wrestler_id); ?></td>
			<td><a href="<?php echo e($wrestler->wiki_link); ?>" style="text-decoration: none;" target="_b"><?php echo e($wrestler->name); ?></a></td>
			<td><?php echo e($wrestler->assigned_show); ?></td>
			<td align="center" style="vertical-align: middle;">
				<form action="<?php echo e(route('wrestlers.destroy', $wrestler->id)); ?>" method="POST">
				<button type="submit" style="background-color: brown;"><a href="<?php echo e(route('wrestlers.edit', $wrestler->id)); ?>" style="color: white; text-decoration: none;">Update</a></button>

				<?php echo csrf_field(); ?>
				<?php echo method_field('DELETE'); ?>

				<button type="submit" style="color: white; background-color: brown;">Release</button>
			</form>
			</td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</table>
</div>
</div>
<?php echo $__env->make('wrestlers.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\JoW\resources\views/wrestlers/index.blade.php ENDPATH**/ ?>