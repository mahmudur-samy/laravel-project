

<?php $__env->startSection('content'); ?>
<head>
	<title>Add New Wrestler's Info</title>
</head>

<h1>Add New Wrestler to the Roster</h1>

<div>
	 <?php if($errors->any()): ?>
      <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      </div><br />
    <?php endif; ?>
	<form action="<?php echo e(route('wrestlers.store')); ?>" method="POST" target="_parent">
		<?php echo csrf_field(); ?>
		Wrestler ID: <input type="text" name="wrestler_id" placeholder="Initials of the Name" style="border: 3px double #CCCCCC;"><br>
		Name: <input type="text" name="name" placeholder="Ring Name" style="border: 3px double #CCCCCC;"><br>
		Assigned Show: <input type="text" name="assigned_show" placeholder="Raw/Smackdown/NXT" style="border: 3px double #CCCCCC;"><br>
		Wikipedia Link: <input type="text" name="wiki_link" placeholder="htttp://wikipedia.org/XXXx" style="border: 3px double #CCCCCC;"><br>
		<br><br>
		<button type="submit" style="color: #FFFFFF; background-color: brown;">Add Wrestler</button>
	</form>
</div>
<?php echo $__env->make('wrestlers.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\JoW\resources\views/wrestlers/create.blade.php ENDPATH**/ ?>