@extends('wrestlers.layout')

@section('content')
<head>
	<title>Update Wrestler's Info</title>
</head>
<h1>Update {{$wrestler->name}}'s Info</h1>
<div>
	 @if ($errors->any())
      <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
              <li>{{ $error }}</li>
            @endforeach
        </ul>
      </div><br />
    @endif
	<div><form action="{{route('wrestlers.update', $wrestler->id)}}" method="POST">
		@csrf
		@method('PUT')
		Wrestler ID: <input type="text" name="wrestler_id" placeholder="Initials of the Ring Name" value="{{$wrestler->wrestler_id}}" style="border: 3px double #CCCCCC;"><br>
		Name: <input type="text" name="name" placeholder="Username" value="{{$wrestler->name}}" style="border: 3px double #CCCCCC;"><br>
		Assigned Show: <input type="text" name="assigned_show" placeholder="Raw/Smackdown/NXT" value="{{$wrestler->assigned_show}}" style="border: 3px double #CCCCCC;"><br>
		Wikipedia: <input type="text" name="join_date" placeholder="htttp://wikipedia.org/XXX" value="{{$wrestler->wiki_link}}" style="border: 3px double #CCCCCC;"><br>
		<br><br>
		<button type="submit" style="color: white; background-color: brown;">Update Wrestler Info</button>
	</form>
</div>