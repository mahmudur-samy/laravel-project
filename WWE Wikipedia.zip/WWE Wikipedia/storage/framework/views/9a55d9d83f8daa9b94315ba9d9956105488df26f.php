

<?php $__env->startSection('content'); ?>
<head>
	<title>Update Wrestler's Info</title>
</head>
<h1>Update <?php echo e($wrestler->name); ?>'s Info</h1>
<div>
	 <?php if($errors->any()): ?>
      <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      </div><br />
    <?php endif; ?>
	<div><form action="<?php echo e(route('wrestlers.update', $wrestler->id)); ?>" method="POST">
		<?php echo csrf_field(); ?>
		<?php echo method_field('PUT'); ?>
		Wrestler ID: <input type="text" name="wrestler_id" placeholder="Initials of the Ring Name" value="<?php echo e($wrestler->wrestler_id); ?>" style="border: 3px double #CCCCCC;"><br>
		Name: <input type="text" name="name" placeholder="Username" value="<?php echo e($wrestler->name); ?>" style="border: 3px double #CCCCCC;"><br>
		Assigned Show: <input type="text" name="assigned_show" placeholder="Raw/Smackdown/NXT" value="<?php echo e($wrestler->assigned_show); ?>" style="border: 3px double #CCCCCC;"><br>
		Wikipedia: <input type="text" name="join_date" placeholder="htttp://wikipedia.org/XXX" value="<?php echo e($wrestler->wiki_link); ?>" style="border: 3px double #CCCCCC;"><br>
		<br><br>
		<button type="submit" style="color: white; background-color: brown;">Update Wrestler Info</button>
	</form>
</div>
<?php echo $__env->make('wrestlers.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\WWE Wikipedia\resources\views/wrestlers/edit.blade.php ENDPATH**/ ?>