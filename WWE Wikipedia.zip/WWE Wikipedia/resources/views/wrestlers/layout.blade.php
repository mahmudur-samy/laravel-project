<!DOCTYPE html>
<html>
<head>
	<title>Current Roster</title>
	<style type="text/css">
		a {
    		text-decoration: none;
		  }
		a:link, a:visited {
   			color: #0C54C8;
		  }
		a:hover {
    		color: red;
		  }
	</style>
</head>
<body align="center" style="color: white; background-color: #1A1110;">
	<div class="container">
		@yield('content')
	</div>
</body>
</html>